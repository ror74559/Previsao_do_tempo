
import geoLocation from './functions/geoLocation.js'

import api from './functions/api.js'

import api2 from './functions/api2.js'




geoLocation()

api()

api2()







