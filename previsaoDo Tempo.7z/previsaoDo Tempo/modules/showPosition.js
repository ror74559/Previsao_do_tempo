 

 export default function showPosition(position) {

					var latlon=`${position.coords.latitude}&log=${position.coords.longitude}`;


					return latlon
			      
				}
 